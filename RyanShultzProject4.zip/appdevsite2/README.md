# appdevsite2

project for app dev due friday, mvc app

search box when blank does not work!!

## install

`npm i ejs express method-override morgan multer nodemon mongoose`
